from koneksi import client

def get_data():
    db = client.influcheck
    items = db.data_user.find()
    items = list(items)
    return items

items = get_data()

for item in items:
    print (item['username'])