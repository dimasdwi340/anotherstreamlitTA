import streamlit as st
import streamlit_authenticator as stauth
from koneksi_db.koneksi_login import items

for item in items:
    names = item['name']
    username = item['username']
    passwords = item['password']


hashed_passwords = stauth.hasher(passwords).generate()

authenticator = stauth.authenticate(names, username, hashed_passwords, 'cookies', '1234', cookie_expiry_days=2)

names, authentication_status = authenticator.login('Login', 'main')

if st.session_state['authentication_status']:
    st.write('Welcome *%s*' % (st.session_state['name']))
    st.title('Some content')
elif st.session_state['authentication_status'] == False:
    st.error('Username/password is incorrect')
elif st.session_state['authentication_status'] == None:
    st.warning('Please enter your username and password')